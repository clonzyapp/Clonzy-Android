
Clonzy Android Full Bundle (Copyright Embedded)
Generated: 2025-10-16T06:20:48.521090Z

This project bundles the Clonzy PWA into the Android assets/www folder and includes copyright notices.

Embedded copyright: "© Shaun Garn 2025 — All Rights Reserved"

What changed:
- All HTML pages in assets/www have a footer with the copyright.
- index.html contains a splash area showing logo + copyright.
- AndroidManifest.xml now includes android:description with copyright.
- Java and Gradle files have a header comment mentioning the copyright.
- An About page (about.html) was added with ownership text.

Next steps:
1) Download the ZIP and upload to a GitHub repo named Clonzy-Android.
2) Use Android Studio to build APK, or ask me to set up CI to build it for you.

Notes:
- This is a UI-bundled APK. Backend features (auth, Stripe, Supabase) require internet and server endpoints.
